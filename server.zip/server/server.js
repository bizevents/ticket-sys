require('dotenv').config();
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const compression = require("compression");
const crypto = require("crypto");
const pool = require('./db/db'); // Ensure you have the pool configuration for DB connection
const Ticket = require('./models/Ticket'); // Ensure correct path to your Ticket model file
const { body, validationResult } = require('express-validator');
const winston = require('winston');

const app = express();

// Middleware
app.use(helmet()); // Set secure HTTP headers
app.use(cors({ origin: ['https://app.bizbazevents.com'] })); // CORS with restricted origin
app.use(compression()); // Gzip compression
app.use(express.json());

// Logger Configuration
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  transports: [
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    new winston.transports.File({ filename: 'combined.log' }),
  ],
});

if (process.env.NODE_ENV !== 'production') {
  logger.add(new winston.transports.Console({
    format: winston.format.simple(),
  }));
}

// Middleware to validate session links
const checkLinkValidity = async (req, res, next) => {
  const { sessionId } = req.query;

  try {
    const [link] = await pool.query('SELECT * FROM links WHERE sessionId = ?', [sessionId]);

    if (!link || link.used || link.expiresAt < new Date()) {
      return res.status(404).json({ message: 'This link is invalid or has expired.' });
    }

    next(); // Proceed if the link is valid
  } catch (err) {
    logger.error('Error validating link:', err);
    res.status(500).json({ message: 'Server error.' });
  }
};

/**
 * Generate a unique session-based link for tickets
 */
app.post("/api/tickets/generate", [
  body('ticketCount').isInt({ min: 1 }).withMessage('Invalid ticket count'),
], async (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { ticketCount } = req.body;
  const sessionId = crypto.randomBytes(16).toString("hex");
  const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // Set expiration to 1 hour

  try {
    await pool.query(
      'INSERT INTO links (sessionId, ticketCount, expiresAt) VALUES (?, ?, ?)',
      [sessionId, ticketCount, expiresAt]
    );

    const uniqueLink = `https://app.bizbazevents.com/tickets?sessionId=${sessionId}&ticketCount=${ticketCount}`;
    res.json({ url: uniqueLink });
  } catch (err) {
    logger.error('Error generating session link:', err);
    next(err);
  }
});

/**
 * Fetch available tickets
 */
app.get('/api/tickets', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM tickets WHERE available = TRUE');

    if (rows.length === 0) {
      return res.status(404).json({ message: 'No available tickets found' });
    }

    res.json(rows);
  } catch (err) {
    logger.error('Error fetching available tickets:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * Reserve tickets
 */
app.post('/api/tickets/reserve', checkLinkValidity, async (req, res) => {
  const { sessionId, ticketIds, firstName, lastName, email, phoneNumber } = req.body;

  try {
    // Process ticket reservation
    const tickets = await Ticket.findAll({
      where: { ticketId: ticketIds },
    });

    const reservedTickets = tickets.filter((ticket) => !ticket.available);

    if (reservedTickets.length > 0) {
      return res.status(400).json({
        message: 'Some tickets are no longer available.',
        reservedTickets: reservedTickets.map((ticket) => ticket.ticketNumber),
      });
    }

    await Ticket.update(
      {
        available: false,
        name: `${firstName} ${lastName}`,
        email,
        phoneNumber,
        reservationDate: new Date(),
      },
      {
        where: { ticketId: ticketIds },
      }
    );

    // Mark the link as used
    await pool.query('UPDATE links SET used = TRUE WHERE sessionId = ?', [sessionId]);

    res.json({ message: 'Tickets reserved successfully!' });
  } catch (error) {
    logger.error('Error reserving tickets:', error);
    res.status(500).json({ message: 'Error reserving tickets.' });
  }
});

/**
 * Validate tickets
 */
app.post('/api/tickets/validate', async (req, res) => {
  const { ticketIds } = req.body;

  try {
    const tickets = await Ticket.findAll({
      where: {
        ticketId: ticketIds,
      },
    });

    const reservedTickets = tickets.filter((ticket) => !ticket.available);

    if (reservedTickets.length > 0) {
      return res.status(400).json({
        message: 'Some tickets are no longer available.',
        reservedTickets: reservedTickets.map((ticket) => ticket.ticketNumber),
      });
    }

    res.json({ message: 'All tickets are still available.' });
  } catch (error) {
    logger.error('Error validating tickets:', error);
    res.status(500).json({ message: 'Error validating tickets.' });
  }
});

/**
 * Fetch reserved tickets
 */
app.get('/api/tickets/reserved', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM tickets WHERE available = FALSE');

    if (rows.length === 0) {
      return res.status(404).json({ message: 'No reserved tickets found' });
    }

    res.json(rows);
  } catch (err) {
    logger.error('Error fetching reserved tickets:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * Handle 404 errors for undefined routes
 */
app.use((req, res) => {
  res.status(404).json({ message: 'Route not found' });
});

/**
 * Centralized Error Handling
 */
app.use((err, req, res, next) => {
  logger.error('Unhandled error:', err.stack);
  res.status(err.status || 500).json({ message: err.message || 'Server error' });
});

// Start the server
const port = process.env.PORT || 5000;
app.listen(port, () => {
  logger.info(`Server running on port ${port}`);
});
