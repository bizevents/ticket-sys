const config = {
    port: 5000,
    db: {
        host: 'localhost',
        user: 'slow',  // Change to your MySQL username
        password: 'Uhgirlu2l8!',  // Change to your MySQL password
        database: 'ticketdb',
    },
  };

module.exports = config;
  